# Fig. 2 Source Data

- figure2_a.csv contains data to plot the traces shown in Fig. 2a

- figure2_bcd_x.csv (x={0, 250, 500, 750} corresponding to levels of dendritic input)
contains the data for Fig. 2b-d and Supplementary Fig. 3
  - columns contain firing rate and CV
  - each row is an individual neuron
  - array in each cell is the response varying the somatic input I_s

  - figure2_e.csv contains data to plot the traces shown in Fig. 2e

  - figure2_control.csv and fig2_MK801.csv contains data for Fig. 2f-h
  
