# Extended Data Fig. 1 Source Data

- ExtendedDataFigure1_bcd.csv contains the data used in the heatmap plots
  - each plot has a row (a, g, c)
  - each entry in the column corresponds to a row of the heatmap

- ExtendedDataFigure1_bcd_inputs.csv contains the Amplitude and Duration values of the heatmap values
